<?php
print "Hello, World!\n";
print "<img src=\"./Haruhi.jpg\" alt=\"Haruhi\">";
?>
